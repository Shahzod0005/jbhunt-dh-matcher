const F = ['scriptUrl', 'scriptKey', 'routeProvider', 'osrmUrl', 'mapboxToken', 'payPct', 'maxDh', 'minRpm', 'avgMph', 'pollSec'];
const NUM = ['payPct', 'maxDh', 'minRpm', 'avgMph', 'pollSec'];
const $ = (id) => document.getElementById(id);
const st = (t, ok) => { $('st').textContent = t; $('st').className = ok ? 'ok' : 'er'; };
const D = self.JBM_DEFAULTS;

function toggle() {
  const p = $('routeProvider').value || D.routeProvider;
  $('osrmBox').classList.toggle('hide', p !== 'osrm');
  $('mbBox').classList.toggle('hide', p !== 'mapbox');
}

chrome.storage.sync.get('settings').then(({ settings }) => {
  const s = settings || {};
  for (const k of F) {
    $(k).value = s[k] ?? '';
    if ($(k).tagName === 'INPUT' && !$(k).placeholder) $(k).placeholder = String(D[k] ?? '');
  }
  toggle();
});
$('routeProvider').onchange = toggle;

async function save() {
  const s = {};
  for (const k of F) {
    const v = $(k).value.trim(); if (v === '') continue;
    s[k] = NUM.includes(k) ? Number(v) : v;
  }
  // o'z serveringiz sslip.io dan boshqa domenda bo'lsa — ruxsat so'raymiz (tugma bosilganda)
  const url = s.osrmUrl || '';
  if (url && !/\.sslip\.io\b|router\.project-osrm\.org/.test(url)) {
    try {
      const origin = new URL(url).origin + '/*';
      const granted = await chrome.permissions.request({ origins: [origin] });
      if (!granted) throw new Error('ruxsat berilmadi');
    } catch (e) { st('OSRM manziliga ruxsat: ' + e.message, false); }
  }
  await chrome.storage.sync.set({ settings: s });
}

$('save').onclick = async () => { await save(); st('Saqlandi ✓', true); };
$('test').onclick = async () => {
  await save(); st('Tekshirilmoqda…', true);
  chrome.runtime.sendMessage({ type: 'testSheet' }, (r) => r && r.ok ? st(`Sheet ulandi ✓ — ${r.n} ta driver`, true) : st('Xato: ' + (r ? r.error : "javob yo'q"), false));
};
$('testR').onclick = async () => {
  await save(); st('Tekshirilmoqda…', true);
  const t = Date.now();
  chrome.runtime.sendMessage({ type: 'testRoute' }, (r) => r && r.ok
    ? st(`Marshrut ishlayapti ✓ — Chicago→Indianapolis ${Math.round(r.mi)} mi, ${Date.now() - t} ms`, true)
    : st('Xato: ' + (r ? r.error : "javob yo'q"), false));
};
