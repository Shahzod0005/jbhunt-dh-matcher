importScripts('config.js', 'lib/core.js');

const M_PER_MI = 1609.344;

// ---------- settings ----------
let settingsCache = null;
async function getSettings() {
  if (settingsCache) return settingsCache;
  const s = await chrome.storage.sync.get('settings');
  const saved = {};
  for (const [k, v] of Object.entries(s.settings || {})) if (v !== '' && v != null) saved[k] = v; // bo'sh qiymat standartni o'chirmasin
  settingsCache = Object.assign({}, self.JBM_DEFAULTS, saved);
  return settingsCache;
}
chrome.storage.onChanged.addListener((ch, area) => {
  if (area === 'sync' && ch.settings) { settingsCache = null; distMem.clear(); persistDist(); restartPoll(); }
});

// ---------- cities (oflayn baza) ----------
let citiesPromise = null;
function cities() {
  if (!citiesPromise) {
    citiesPromise = fetch(chrome.runtime.getURL('data/cities.json'))
      .then(r => r.json()).then(obj => JBCore.buildIndex(obj));
  }
  return citiesPromise;
}

const geoMem = new Map();
async function geocode(raw) {
  const p = JBCore.parsePlace(raw);
  if (!p) return null;
  const key = p.city + '|' + p.st;
  if (geoMem.has(key)) return geoMem.get(key);
  const idx = await cities();
  let hit = JBCore.lookup(idx, p);
  if (!hit) {
    const st = await chrome.storage.local.get('g:' + key);
    if (st['g:' + key]) hit = st['g:' + key];
  }
  if (!hit) hit = await nominatim(p, key);
  geoMem.set(key, hit || null);
  return hit || null;
}

let nomChain = Promise.resolve();
function nominatim(p, key) {
  const job = nomChain.then(async () => {
    try {
      const q = encodeURIComponent(p.cityRaw + ', ' + p.st + ', USA');
      const r = await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=us&q=' + q);
      const j = await r.json();
      if (j && j[0]) {
        const hit = { lat: +j[0].lat, lon: +j[0].lon, how: 'online' };
        await chrome.storage.local.set({ ['g:' + key]: hit });
        return hit;
      }
    } catch (e) {}
    return null;
  });
  nomChain = job.then(() => new Promise(r => setTimeout(r, 1100)));
  return job;
}

// ---------- drivers (jonli + doimiy kesh) ----------
let drv = { ts: 0, list: null, inflight: null };
const drvLoaded = chrome.storage.local.get('drivers').then(o => {
  if (o.drivers && !drv.list) drv = { ts: o.drivers.ts, list: o.drivers.list, inflight: null };
});

async function fetchDrivers() {
  const s = await getSettings();
  if (!s.scriptUrl || !s.scriptKey) throw new Error('Sozlamada Apps Script URL / kalit kiritilmagan');
  const url = s.scriptUrl + (s.scriptUrl.includes('?') ? '&' : '?') + 'key=' + encodeURIComponent(s.scriptKey) + '&t=' + Date.now();
  const r = await fetch(url, { cache: 'no-store' });
  const j = await r.json();
  if (!j.ok) throw new Error('Sheet: ' + (j.error || 'xato'));
  drv = { ts: Date.now(), list: j.drivers, inflight: null };
  chrome.storage.local.set({ drivers: { ts: drv.ts, list: drv.list } });
  return drv.list;
}
function refreshDrivers() {
  if (!drv.inflight) drv.inflight = fetchDrivers().catch(e => { drv.inflight = null; throw e; });
  return drv.inflight;
}
async function getDrivers(fresh) {
  await drvLoaded;
  if (!fresh && drv.list && Date.now() - drv.ts < 10 * 60 * 1000) {
    if (Date.now() - drv.ts > 15000) refreshDrivers().catch(() => {}); // fon so'rovi to'xtab qolgan bo'lsa ham eskirmasin
    return drv.list;
  }
  return refreshDrivers();
}

// ---------- JB sahifasi ochiq ekan: uyg'oq turish + fonda yangilash ----------
const ports = new Map(); // port -> {visible}
let pollTimer = null;
function anyVisible() { for (const v of ports.values()) if (v.visible) return true; return false; }
async function restartPoll() {
  clearInterval(pollTimer); pollTimer = null;
  if (!ports.size) return;
  const s = await getSettings();
  pollTimer = setInterval(() => { if (anyVisible()) refreshDrivers().catch(() => {}); }, Math.max(5, s.pollSec) * 1000);
}
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'jb') return;
  ports.set(port, { visible: true });
  cities(); drvLoaded.then(() => { if (Date.now() - drv.ts > 5000) refreshDrivers().catch(() => {}); });
  if (!pollTimer) restartPoll();
  port.onMessage.addListener((m) => {
    const was = anyVisible();
    ports.set(port, { visible: !!m.visible });
    if (!was && m.visible && Date.now() - drv.ts > 5000) refreshDrivers().catch(() => {}); // tabga qaytganda darhol
  });
  port.onDisconnect.addListener(() => { ports.delete(port); if (!ports.size) { clearInterval(pollTimer); pollTimer = null; } });
});

// ---------- masofa: provayder + doimiy kesh ----------
const distMem = new Map();
const DIST_CAP = 40000;
const distLoaded = chrome.storage.local.get('dist').then(o => { for (const [k, v] of Object.entries(o.dist || {})) distMem.set(k, v); });
let distSaveT = null;
function persistDist() {
  clearTimeout(distSaveT);
  distSaveT = setTimeout(() => {
    while (distMem.size > DIST_CAP) distMem.delete(distMem.keys().next().value);
    chrome.storage.local.set({ dist: Object.fromEntries(distMem) });
  }, 1500);
}
const ck = c => c.lon.toFixed(4) + ',' + c.lat.toFixed(4);

function provider(s) {
  if (s.routeProvider === 'mapbox') {
    if (!s.mapboxToken) throw new Error('Sozlamada Mapbox token kiritilmagan');
    return {
      batch: 24,
      url: (coords, n) => 'https://api.mapbox.com/directions-matrix/v1/mapbox/driving/' + coords +
        '?annotations=distance&destinations=' + n + '&sources=' + [...Array(n).keys()].join(';') +
        '&access_token=' + encodeURIComponent(s.mapboxToken)
    };
  }
  const base = String(s.osrmUrl || 'https://router.project-osrm.org').replace(/\/+$/, '');
  return {
    batch: 90,
    url: (coords, n) => base + '/table/v1/driving/' + coords + '?annotations=distance&destinations=' + n +
      '&sources=' + [...Array(n).keys()].join(';')
  };
}

async function fetchJson(url, ms) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), ms);
  try { const r = await fetch(url, { signal: ctl.signal }); return await r.json(); }
  catch (e) { throw new Error(e.name === 'AbortError' ? 'Marshrut serveri javob bermadi' : 'Marshrut serveri: ' + e.message); }
  finally { clearTimeout(t); }
}

async function distTable(srcs, dst) {
  await distLoaded;
  const s = await getSettings(); const pv = provider(s);
  const out = new Array(srcs.length).fill(null); const need = [];
  srcs.forEach((c, i) => {
    const k = ck(c) + '>' + ck(dst);
    if (distMem.has(k)) out[i] = distMem.get(k); else need.push(i);
  });
  const jobs = [];
  for (let b = 0; b < need.length; b += pv.batch) {
    const part = need.slice(b, b + pv.batch);
    const coords = part.map(i => ck(srcs[i])).concat([ck(dst)]).join(';');
    jobs.push(fetchJson(pv.url(coords, part.length), 8000).then(j => {
      if (j.code !== 'Ok') throw new Error('Marshrut serveri: ' + (j.message || j.code));
      part.forEach((i, k) => {
        const m = j.distances[k][0];
        const mi = m == null ? null : m / M_PER_MI;
        out[i] = mi; distMem.set(ck(srcs[i]) + '>' + ck(dst), mi);
      });
    }));
  }
  await Promise.all(jobs);
  if (need.length) persistDist();
  return out;
}

// ---------- asosiy hisob ----------
async function compute(load, fresh) {
  const s = await getSettings();
  const t0 = Date.now();
  const [drivers, pu, del] = await Promise.all([getDrivers(fresh), geocode(load.origin), geocode(load.dest)]);
  if (!pu) throw new Error('PU topilmadi: ' + load.origin);
  if (!del) throw new Error('DEL topilmadi: ' + load.dest);

  const pay = load.rpm * s.payPct * load.miles;
  const delSt = (JBCore.parsePlace(load.dest) || {}).st;

  const geo = await Promise.all(drivers.map(d => d.loc ? geocode(d.loc) : Promise.resolve(null)));
  const noLoc = [], notFound = [], cand = [];
  let farAir = 0;
  drivers.forEach((d, i) => {
    if (!d.loc) { noLoc.push(d.truck || d.name); return; }
    if (!geo[i]) { notFound.push((d.truck || d.name) + ' (' + d.loc + ')'); return; }
    if (JBCore.haversineMi(geo[i], pu) > s.maxDh) { farAir++; return; }
    cand.push({ d, c: geo[i] });
  });

  const [dhList, loadedArr] = await Promise.all([
    cand.length ? distTable(cand.map(x => x.c), pu) : Promise.resolve([]),
    distTable([pu], del)
  ]);
  const loaded = loadedArr[0];
  if (loaded == null) throw new Error('PU→DEL marshruti topilmadi');

  let overDh = farAir, lowRate = 0;
  const ok = [], late = [];
  cand.forEach((x, i) => {
    const dh = dhList[i];
    if (dh == null || dh > s.maxDh) { overDh++; return; }
    const total = dh + loaded;
    const rpm = pay / total;
    if (rpm <= s.minRpm) { lowRate++; return; }
    const banned = JBCore.bannedStates(x.d.note);
    const tm = JBCore.timing(x.d, load.pickup, dh, s.avgMph);
    const r = { truck: x.d.truck, name: x.d.name, date: x.d.date, status: x.d.status, note: x.d.note, dh, rpm,
      warn: !!delSt && banned.includes(delSt), time: tm, fuzzy: x.c.how === 'fuzzy' ? x.c.name : null };
    (tm.state === 'late' ? late : ok).push(r);
  });
  ok.sort((a, b) => b.rpm - a.rpm);
  late.sort((a, b) => a.time.lateMin - b.time.lateMin);

  return {
    ok: true, pay, loaded, rows: ok, late,
    settings: { maxDh: s.maxDh, minRpm: s.minRpm, payPct: s.payPct },
    stats: { total: drivers.length, overDh, lowRate, noLoc, notFound },
    driversTs: drv.ts, ms: Date.now() - t0
  };
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg.type === 'compute') {
    compute(msg.load, !!msg.fresh).then(reply, e => reply({ ok: false, error: e.message }));
    return true;
  }
  if (msg.type === 'testSheet') {
    fetchDrivers().then(l => reply({ ok: true, n: l.length }), e => reply({ ok: false, error: e.message }));
    return true;
  }
  if (msg.type === 'testRoute') {
    // Chicago -> Indianapolis
    distTable([{ lat: 41.8781, lon: -87.6298 }], { lat: 39.7684, lon: -86.1581 })
      .then(([mi]) => reply({ ok: mi != null, mi }), e => reply({ ok: false, error: e.message }));
    return true;
  }
});

chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());
