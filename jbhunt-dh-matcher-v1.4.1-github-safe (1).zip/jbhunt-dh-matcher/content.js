(() => {
  if (window.__jbm) return; window.__jbm = true;

  const send = (msg) => new Promise((res) => {
    try { chrome.runtime.sendMessage(msg, (r) => res(r || { ok: false, error: chrome.runtime.lastError?.message || 'no reply' })); }
    catch (e) { res({ ok: false, error: e.message }); }
  });

  // ---------- jadvalni o'qish ----------
  const KEYS = [
    ['order', /^order/], ['origin', /^origin/], ['dest', /^destination/], ['pickup', /^pickup/],
    ['delivery', /^delivery/], ['miles', /^miles/], ['linehaul', /^linehaul/], ['fuel', /^estimated fuel|^fuel/],
    ['rpm', /^rate per mile/], ['equip', /^equipment/], ['weight', /^weight/], ['note', /^note/]
  ];
  const norm = (s) => String(s || '').replace(/\s+/g, ' ').trim();
  const money = (s) => { const v = parseFloat(String(s).replace(/[^0-9.\-]/g, '')); return isFinite(v) ? v : 0; };

  function headerMap(table) {
    for (const tr of table.querySelectorAll('tr')) {
      const cells = [...tr.children].map(c => norm(c.textContent).toLowerCase());
      if (cells.some(c => /^rate per mile/.test(c)) && cells.some(c => /^origin/.test(c))) {
        const map = {};
        cells.forEach((c, i) => { for (const [k, re] of KEYS) if (map[k] == null && re.test(c)) map[k] = i; });
        return map;
      }
    }
    return null;
  }

  function readRow(radio) {
    const tr = radio.closest('tr'); const table = tr && tr.closest('table');
    if (!table) return null;
    const map = headerMap(table); if (!map) return null;
    const td = [...tr.children]; const g = (k) => map[k] != null && td[map[k]] ? norm(td[map[k]].textContent) : '';
    const miles = money(g('miles')), lh = money(g('linehaul')), fuel = money(g('fuel'));
    let rpm = money(g('rpm'));
    if (!rpm && miles && lh > 1) rpm = (lh + fuel) / miles;
    return { tr, order: g('order'), origin: g('origin'), dest: g('dest'), pickup: g('pickup'), delivery: g('delivery'),
      miles, linehaul: lh, fuel, rpm, rpmText: g('rpm') };
  }

  // ---------- popup ----------
  let host, root, cur = null, seq = 0, tsTimer = null;

  const CSS = `
  :host{all:initial}
  .p{position:fixed;top:6px;right:6px;z-index:2147483646;width:max-content;max-width:calc(100vw - 12px);
     max-height:calc(100vh - 12px);display:flex;flex-direction:column;background:#fff;color:#14202b;
     font:11.5px/1.3 "Segoe UI",Roboto,Arial,sans-serif;border:1px solid #1f4e79;border-radius:7px;
     box-shadow:0 8px 24px rgba(10,30,50,.28);overflow:hidden}
  .hd{display:flex;align-items:center;gap:8px;padding:4px 6px 4px 9px;background:#1f4e79;color:#fff;cursor:move;user-select:none;white-space:nowrap}
  .hd b{font-size:12px}.hd .rt{font-variant-numeric:tabular-nums}.sp{flex:1}
  .hd button{all:unset;cursor:pointer;padding:1px 6px;border-radius:4px;color:#fff;font-size:13px}
  .hd button:hover{background:rgba(255,255,255,.18)}
  .sub{display:flex;gap:10px;padding:3px 9px;background:#eef4fa;border-bottom:1px solid #d3e0ec;font-variant-numeric:tabular-nums;white-space:nowrap}
  .sub span b{color:#1f4e79}
  .ts{color:#5a6b7b}.ts.old{color:#b45309}
  .wrap{flex:1 1 auto;min-height:0;overflow:auto}
  table{border-collapse:collapse;font:inherit;color:inherit}
  th,td{font-size:11.5px}
  th{position:sticky;top:0;background:#f6f8fa;color:#405060;font-weight:600;text-align:left;padding:3px 6px;border-bottom:1px solid #d8dee4;white-space:nowrap}
  td{padding:2px 6px;border-bottom:1px solid #eef1f4;white-space:nowrap;font-variant-numeric:tabular-nums}
  td.n,th.n{text-align:right}
  tr.r{cursor:pointer}tr.r:hover td{background:#fff8db}
  tr.sel td{background:#dcfce7!important}
  tr.warn td{background:#ffedd5}
  tr.late td{background:#fee2e2;color:#7f1d1d}tr.late .rpm{color:#b91c1c}
  tr.sep td{background:#b91c1c;color:#fff;font-weight:700;padding:2px 6px}
  .lt{color:#b91c1c;font-weight:700;font-size:11px}.uk{color:#92400e;font-weight:700;cursor:help}
  .rpm{font-weight:700;color:#15803d}
  .pill{display:inline-block;padding:0 5px;border-radius:8px;background:#e5e7eb;font-size:10.5px}
  .pill.ready{background:#dcfce7;color:#166534}.pill.etr{background:#dbeafe;color:#1e40af}.pill.eta{background:#fef3c7;color:#92400e}
  .nm{max-width:110px;overflow:hidden;text-overflow:ellipsis}
  .note{max-width:150px;overflow:hidden;text-overflow:ellipsis;color:#4b5563}
  .w{color:#b91c1c;font-weight:700}
  .fz{color:#b45309;cursor:help}
  a.m{color:#1f4e79;text-decoration:none;font-weight:600}a.m:hover{text-decoration:underline}
  .ft{padding:3px 9px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#5a6b7b;border-top:1px solid #eef1f4;background:#fafbfc}
  .ft details{display:inline}.ft summary{cursor:pointer;display:inline}
  .msg{padding:10px;color:#334155}.err{color:#b91c1c}
  .ld{padding:10px;color:#5a6b7b}
  .toast{position:absolute;right:10px;bottom:8px;background:#14532d;color:#fff;padding:4px 10px;border-radius:5px;opacity:0;transition:opacity .2s}
  .toast.on{opacity:1}
  `;

  function ensureHost() {
    if (host && host.isConnected) return;
    host = document.createElement('div'); host.id = 'jbm-host';
    root = host.attachShadow({ mode: 'open' });
    root.innerHTML = `<style>${CSS}</style><div class="p" style="display:none"></div>`;
    document.body.appendChild(host);
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
  }
  const panel = () => root.querySelector('.p');
  function close() { if (panel()) panel().style.display = 'none'; cur = null; seq++; clearInterval(tsTimer); clearInterval(liveTimer); }

  let dragged = null; // {left, top} — sudralsa sessiya davomida shu joyda qoladi
  function place() {
    const p = panel(); p.style.display = 'flex';
    if (dragged) { p.style.left = dragged.left + 'px'; p.style.top = dragged.top + 'px'; p.style.right = 'auto'; }
  }

  function drag(p) {
    const hd = p.querySelector('.hd'); if (!hd) return;
    hd.onmousedown = (e) => {
      if (e.target.closest('button')) return;
      const r = p.getBoundingClientRect(), sx = e.clientX, sy = e.clientY;
      const mv = (ev) => {
        dragged = { left: Math.max(0, r.left + ev.clientX - sx), top: Math.max(0, r.top + ev.clientY - sy) };
        p.style.left = dragged.left + 'px'; p.style.top = dragged.top + 'px'; p.style.right = 'auto';
      };
      const up = () => { document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up); };
      document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up);
    };
    hd.ondblclick = (e) => { if (e.target.closest('button')) return; dragged = null; p.style.left = ''; p.style.top = ''; p.style.right = ''; };
  }

  const sd = (d) => { const m = String(d || '').match(/^\d{4}-(\d{2})-(\d{2})/); return m ? m[1] + '/' + m[2] : esc(d); };
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const f0 = (n) => Math.round(n).toLocaleString('en-US');
  const f2 = (n) => n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const pill = (s) => { const u = String(s).toUpperCase(); const c = u.startsWith('READY') ? 'ready' : u.startsWith('ETR') ? 'etr' : u.startsWith('ETA') ? 'eta' : ''; return `<span class="pill ${c}">${esc(s || '—')}</span>`; };

  function head(load, res) {
    const pay = res && res.ok ? res.pay : load.rpm * 0.82 * load.miles;
    const pct = res && res.ok ? res.settings.payPct : 0.82;
    return `<div class="hd"><b>${esc(load.order)}</b><span>${esc(load.origin)} → ${esc(load.dest)}</span><span class="sp"></span>
      <span class="rt">$${f2(load.rpm)} × ${Math.round(pct * 100)}% × ${f0(load.miles)} mi = <b>$${f2(pay)}</b></span>
      <button data-a="re" title="Qayta hisoblash">⟳</button><button data-a="x" title="Yopish (Esc)">✕</button></div>`;
  }

  function render(load, res) {
    const p = panel();
    if (!res) { p.innerHTML = head(load) + `<div class="ld">Hisoblanmoqda…</div>`; bind(load); return; }
    if (!res.ok) { p.innerHTML = head(load) + `<div class="msg err">⚠ ${esc(res.error)}</div>`; bind(load); return; }
    const s = res.settings, st = res.stats;
    const dSt = esc(load.dest.split(',').pop().trim());
    const hm = (m) => Math.floor(m / 60) + ':' + String(m % 60).padStart(2, '0');
    const row = (r, late) => `
      <tr class="r${late ? ' late' : r.warn ? ' warn' : ''}" data-t="${esc(r.truck)}">
        <td><b>${esc(r.truck)}</b></td><td class="nm" title="${esc(r.name)}">${esc(r.name)}</td><td>${sd(r.date)}</td>
        <td>${pill(r.status)}${late ? ` <span class="lt">+${hm(r.time.lateMin)} kech</span>` : r.time.state === 'unknown' && !/\?/.test(r.status) ? ` <span class="uk" title="Vaqt noma'lum — tekshiring">?</span>` : ''}</td>
        <td class="n">${f0(r.dh)}${r.fuzzy ? ` <span class="fz" title="Lokatsiya taxminiy topildi: ${esc(r.fuzzy)}">≈</span>` : ''}</td>
        <td class="n rpm">$${f2(r.rpm)}</td>
        <td class="note" title="${esc(r.note)}">${r.warn ? `<span class="w">⚠ ${dSt} taqiqlangan · </span>` : ''}${esc(r.note)}</td>
      </tr>`;
    const late = res.late || [];
    const rows = res.rows.map(r => row(r, false)).join('') +
      (late.length ? `<tr class="sep"><td colspan="7">⏰ PU vaqtiga ulgurmaydi (${late.length})</td></tr>` + late.map(r => row(r, true)).join('') : '');
    const nf = st.notFound.length ? ` · <span class="w" title="${esc(st.notFound.join('; '))}">${st.notFound.length} topilmadi</span>` : '';
    p.innerHTML = head(load, res) + `
      <div class="sub"><span>Marshrut <b>${f0(res.loaded)}</b> mi (board ${f0(load.miles)})</span>
        <span>Mos <b>${res.rows.length}</b>${late.length ? ` <span class="lt">+${late.length} kech</span>` : ''} / ${st.total}</span>
        <span class="ts" data-ts="${res.driversTs}"></span></div>
      ${res.rows.length + late.length ? `<div class="wrap"><table><thead><tr><th>Driver ID</th><th>Driver</th><th>Sana</th><th>Status</th><th class="n">DH</th><th class="n">$/mi</th><th>Note</th></tr></thead><tbody>${rows}</tbody></table></div>`
        : `<div class="msg">Shartga mos driver yo'q (DH ≤ ${s.maxDh}, $/mi > ${f2(s.minRpm)}).</div>`}
      <div class="ft">DH>${s.maxDh}: ${st.overDh} · rate past: ${st.lowRate} · lok. yo'q: ${st.noLoc.length}${nf}</div>
      <div class="toast"></div>`;
    bind(load);
    tickTs(); clearInterval(tsTimer); tsTimer = setInterval(tickTs, 1000);
  }

  function tickTs() {
    const el = root.querySelector('.ts'); if (!el) return;
    const sec = Math.max(0, Math.round((Date.now() - +el.dataset.ts) / 1000));
    el.textContent = (sec < 60 ? sec + ' sek' : Math.round(sec / 60) + ' daq') + ' oldin';
    el.classList.toggle('old', sec > 60);
  }

  function bind(load) {
    const p = panel(); drag(p);
    p.querySelector('[data-a="x"]').onclick = close;
    p.querySelector('[data-a="re"]').onclick = () => run(load, true);
    p.querySelectorAll('tr.r').forEach(tr => tr.onclick = (e) => {
      if (e.target.closest('a')) return;
      p.querySelectorAll('tr.sel').forEach(x => x.classList.remove('sel')); tr.classList.add('sel');
      const t = tr.dataset.t; const ok = fillPcs(t);
      try { navigator.clipboard.writeText(t); } catch (_) {}
      toast(ok ? `PCS: ${t} yozildi` : `${t} nusxalandi (PCS maydoni topilmadi)`);
    });
  }

  function toast(txt) {
    const t = root.querySelector('.toast'); if (!t) return;
    t.textContent = txt; t.classList.add('on'); clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove('on'), 1800);
  }

  function fillPcs(val) {
    const docs = [document];
    try { if (window.top !== window && window.top.document) docs.push(window.top.document); } catch (_) {}
    for (const d of docs) {
      const inputs = [...d.querySelectorAll('input[type="text"],input:not([type])')];
      let inp = inputs.find(i => /pcs|tractor/i.test((i.name || '') + (i.id || '')));
      if (!inp) inp = inputs.find(i => { const c = i.closest('td,tr,div,form'); return c && /PCS\s*Tractor/i.test(c.textContent); });
      if (inp) {
        inp.focus(); inp.value = val;
        inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      }
    }
    return false;
  }

  // ---------- oqim ----------
  const sig = (r) => r && r.ok ? r.rows.concat(r.late || []).map(x => x.truck + ':' + x.rpm.toFixed(2) + ':' + x.time.state).join('|') + '#' + r.stats.total : JSON.stringify(r);

  let liveTimer = null, lastSig = '';
  function apply(load, res, my) {
    if (my !== seq || !res) return;
    const g = sig(res);
    if (g !== lastSig) {
      const w = root.querySelector('.wrap'); const top = w ? w.scrollTop : 0;
      const sel = root.querySelector('tr.sel'); const selT = sel && sel.dataset.t;
      render(load, res); lastSig = g;
      const w2 = root.querySelector('.wrap'); if (w2) w2.scrollTop = top;
      if (selT) { const t = root.querySelector(`tr.r[data-t="${CSS.escape(selT)}"]`); if (t) t.classList.add('sel'); }
    } else if (res.ok) {
      const el = root.querySelector('.ts'); if (el) { el.dataset.ts = res.driversTs; tickTs(); }
    }
  }

  async function run(load, forceFresh) {
    const my = ++seq; cur = load; lastSig = ''; clearInterval(liveTimer);
    if (!forceFresh) render(load, null);
    const req = { origin: load.origin, dest: load.dest, rpm: load.rpm, miles: load.miles, pickup: load.pickup };
    // 1) keshdagi ro'yxat bilan darhol
    const first = await send({ type: 'compute', load: req, fresh: !!forceFresh });
    apply(load, first, my);
    if (my !== seq || !first.ok) return;
    // 2) jonli ro'yxat bilan tekshirish
    if (!forceFresh && (Date.now() - first.driversTs) / 1000 >= 3) {
      const second = await send({ type: 'compute', load: req, fresh: true });
      if (second.ok) apply(load, second, my);
    }
    // 3) oyna ochiq ekan — har 10 sek fonda yangilangan ro'yxat bo'yicha qayta hisob (o'zgarsa yangilanadi)
    liveTimer = setInterval(async () => {
      if (my !== seq || !cur || document.visibilityState !== 'visible') return;
      const r = await send({ type: 'compute', load: req, fresh: false });
      if (r.ok) apply(load, r, my);
    }, 10000);
  }

  function handle(radio) {
    const load = readRow(radio); if (!load) return;
    ensureHost(); place();
    if (!(load.linehaul > 1) || !load.rpm || !load.miles) {
      panel().innerHTML = `<div class="hd"><b>${esc(load.order)}</b><span class="sp"></span><button data-a="x">✕</button></div>
        <div class="msg">Board'da rate yo'q (${esc(load.rpmText || '—')}) — hisoblab bo'lmaydi.</div>`;
      panel().querySelector('[data-a="x"]').onclick = close; drag(panel()); return;
    }
    run(load, false);
  }

  // fon qismini uyg'oq tutish + Sheet'ni fonda yangilatish (faqat JB sahifasi ochiq ekan)
  function keepAlive() {
    let port = null;
    const vis = () => document.visibilityState === 'visible';
    const connect = () => {
      try {
        port = chrome.runtime.connect({ name: 'jb' });
        port.onDisconnect.addListener(() => { port = null; setTimeout(connect, 1000); });
        port.postMessage({ visible: vis() });
      } catch (_) { port = null; }
    };
    connect();
    setInterval(() => { try { port ? port.postMessage({ visible: vis() }) : connect(); } catch (_) { connect(); } }, 20000);
    document.addEventListener('visibilitychange', () => { try { port && port.postMessage({ visible: vis() }); } catch (_) {} });
  }

  function hasBoard() { return [...document.querySelectorAll('table')].some(t => headerMap(t)); }

  function init() {
    if (!hasBoard()) return;
    keepAlive();
    document.addEventListener('click', (e) => {
      const r = e.target.closest && e.target.closest('input[type="radio"]');
      if (r && r.closest('tr')) setTimeout(() => handle(r), 0);
    }, true);
    // yuk tanlangach sahifa qayta yuklansa — belgilangan qatorni avtomat ochamiz
    const checked = [...document.querySelectorAll('input[type="radio"]:checked')].find(r => r.closest('tr'));
    if (checked) handle(checked);
  }
  init();
})();
