#!/usr/bin/env bash
# JB Hunt DH Matcher — o'z marshrut serveringiz (OSRM, butun AQSh, yengil mashina)
# Ubuntu 22.04/24.04, root sifatida:  bash setup-osrm.sh
# Talab: RAM >= 64 GB (kamroq bo'lsa swap qo'shiladi, lekin qurish juda sekinlashadi), disk >= 250 GB.
# Birinchi qurish 1–3 soat oladi. Keyin server doimiy ishlaydi, qayta yuklansa ham o'zi ko'tariladi.
set -euo pipefail

IMG=ghcr.io/project-osrm/osrm-backend:v5.27.1
PBF_URL=https://download.geofabrik.de/north-america/us-latest.osm.pbf
DIR=/srv/osrm
SECRET=${SECRET:-$(tr -dc 'a-zA-Z0-9' </dev/urandom | head -c 20)}
IP=$(curl -4 -s https://api.ipify.org)
DOMAIN="${IP//./-}.sslip.io"

echo "== 1/6 Paketlar"
apt-get update -y && apt-get install -y docker.io curl ufw
systemctl enable --now docker

echo "== 2/6 Swap (RAM 64 GB dan kam bo'lsa)"
RAM_GB=$(awk '/MemTotal/ {printf "%d", $2/1024/1024}' /proc/meminfo)
if [ "$RAM_GB" -lt 60 ] && [ ! -f /swapfile ]; then
  fallocate -l 48G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile
  echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi

echo "== 3/6 AQSh xaritasi yuklanmoqda (~11 GB)"
mkdir -p $DIR && cd $DIR
[ -f us-latest.osm.pbf ] || curl -L -o us-latest.osm.pbf "$PBF_URL"

echo "== 4/6 Marshrut grafigi qurilmoqda (eng uzun qadam)"
[ -f us-latest.osrm.cells ] || {
  docker run --rm -t -v $DIR:/data $IMG osrm-extract -p /opt/car.lua /data/us-latest.osm.pbf
  docker run --rm -t -v $DIR:/data $IMG osrm-partition /data/us-latest.osrm
}
docker run --rm -t -v $DIR:/data $IMG osrm-customize /data/us-latest.osrm

echo "== 5/6 Server ishga tushirilmoqda"
docker network inspect osrmnet >/dev/null 2>&1 || docker network create osrmnet
docker rm -f osrm caddy >/dev/null 2>&1 || true
docker run -d --name osrm --restart always --network osrmnet -v $DIR:/data $IMG \
  osrm-routed --algorithm mld --max-table-size 1000 /data/us-latest.osrm

mkdir -p /srv/caddy
cat > /srv/caddy/Caddyfile <<EOF
$DOMAIN {
  handle_path /$SECRET/* {
    reverse_proxy osrm:5000
  }
  respond 403
}
EOF
docker run -d --name caddy --restart always --network osrmnet -p 80:80 -p 443:443 \
  -v /srv/caddy/Caddyfile:/etc/caddy/Caddyfile -v /srv/caddy/data:/data caddy:2

echo "== 6/6 Firewall"
ufw allow 22/tcp && ufw allow 80/tcp && ufw allow 443/tcp && ufw --force enable

sleep 15
URL="https://$DOMAIN/$SECRET"
echo
echo "Tekshiruv (Chicago -> Indianapolis):"
curl -s "$URL/table/v1/driving/-87.6298,41.8781;-86.1581,39.7684?annotations=distance&sources=0&destinations=1" | head -c 200; echo
echo
echo "================================================================"
echo " Extension sozlamasiga yozing:  OSRM URL = $URL"
echo " (shu manzilni hech kimga bermang — maxfiy qism unda)"
echo "================================================================"
echo "$URL" > /root/osrm-url.txt
