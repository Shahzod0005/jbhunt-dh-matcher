# JB Hunt DH Matcher v1.4.1

A Chrome extension designed to support daily trucking dispatch operations by matching available drivers with suitable loads on the JB Hunt Load Board.

## Overview

The extension helps dispatchers evaluate potential driver-load matches using deadhead distance, estimated revenue per mile, route distance, and pickup-time feasibility. It is intended to reduce repetitive manual work and make load searches more efficient.

## Features

- Matches loads with drivers listed in a Combined Ready List.
- Calculates deadhead distance to pickup.
- Estimates revenue per mile using configurable pay assumptions.
- Evaluates whether a driver can reach pickup within the available time window.
- Supports route-distance lookup and caches previously calculated routes.
- Allows dispatchers to select a match and transfer the Driver ID into the PCS Tractor Number field.
- Provides configurable matching and refresh settings.

## Configuration

Before use, configure your own authorized Google Apps Script endpoint and secret in the extension settings. Do not commit credentials, private spreadsheet links, API tokens, driver information, or company-sensitive data. The distributed `config.js` has been cleared of the original endpoint and key.

## Installation

1. Download or clone this repository.
2. Open `chrome://extensions` in Google Chrome.
3. Enable **Developer mode**.
4. Select **Load unpacked** and choose the extension folder.
5. Configure the backend connection in the extension options.

## Technology

- JavaScript
- Chrome Extensions Manifest V3
- Google Apps Script / Google Sheets integration
- OSRM routing (configurable)

## Project impact

Built around real dispatch workflow needs, this tool helps reduce repetitive load-search steps, identify suitable driver-load combinations faster, and improve day-to-day dispatch efficiency.

## Security and usage

Use only with systems and data you are authorized to access. This project is an independent productivity tool and is not an official JB Hunt product. Keep the repository private unless you have permission to publish the code and have reviewed it for proprietary or confidential information.
