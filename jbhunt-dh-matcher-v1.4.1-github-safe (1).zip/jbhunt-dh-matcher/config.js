// Standart sozlamalar. Tarqatishdan OLDIN shu yerni bir marta to'ldiring —
// shunda har bir profilda sozlama kiritish shart bo'lmaydi.
// (Sozlamalar sahifasida kiritilgan qiymat bu yerdagidan ustun turadi.)
self.JBM_DEFAULTS = {
  scriptUrl: '',            // Apps Script Web App URL (https://script.google.com/macros/s/.../exec)
  scriptKey: '',            // Code.gs dagi SECRET bilan bir xil

  routeProvider: 'osrm',    // 'osrm' (o'z serveringiz yoki ochiq server) | 'mapbox'
  osrmUrl: 'https://router.project-osrm.org',  // o'z serveringiz: https://1-2-3-4.sslip.io/MAXFIY
  mapboxToken: '',          // routeProvider='mapbox' bo'lsa

  payPct: 0.82,             // Board RPM ning necha foizi olinadi
  maxDh: 200,               // Maksimal DH (mile)
  minRpm: 2.40,             // DH bilan minimal $/mile
  avgMph: 50,               // DH yo'lini necha soatda bosishini hisoblash uchun o'rtacha tezlik
  pollSec: 10               // JB sahifasi ochiq bo'lsa, Sheet har necha soniyada yangilanadi
};
