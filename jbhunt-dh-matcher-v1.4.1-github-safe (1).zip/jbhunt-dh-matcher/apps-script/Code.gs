/**
 * JB Hunt DH Matcher — Combined Ready List "eshigi"
 * Joylashtirish: Sheet ichida Extensions → Apps Script → shu kodni qo'ying →
 * Deploy → New deployment → Web app → Execute as: Me, Who has access: Anyone → Deploy.
 * Chiqqan URL va quyidagi SECRET ni extension sozlamalariga kiriting.
 */
const SECRET = 'BU_YERGA_O_ZINGIZNING_MAXFIY_SOZINGIZ';   // masalan: jb-7Kq29xLm
const SHEET_NAME = 'Combined Ready List';
const FIRST_ROW = 4; // sarlavha 3-qatorda

function doGet(e) {
  if (!e || !e.parameter || e.parameter.key !== SECRET) {
    return out_({ ok: false, error: 'bad key' });
  }
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  if (!sh) return out_({ ok: false, error: 'sheet not found: ' + SHEET_NAME });
  const last = sh.getLastRow();
  if (last < FIRST_ROW) return out_({ ok: true, ts: Date.now(), drivers: [] });
  const vals = sh.getRange(FIRST_ROW, 1, last - FIRST_ROW + 1, 7).getDisplayValues();
  const drivers = [];
  for (const r of vals) {
    const name = String(r[1] || '').trim();
    if (!name) continue;
    drivers.push({
      date: String(r[0] || '').trim(),
      name: name,
      loc: String(r[2] || '').trim(),
      truck: String(r[3] || '').trim(),
      status: String(r[4] || '').trim(),
      company: String(r[5] || '').trim(),
      note: String(r[6] || '').trim()
    });
  }
  return out_({ ok: true, ts: Date.now(), drivers: drivers });
}

function out_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
